-- ================================================
--  BANKING SYSTEM - MySQL Version (For XAMPP)
--  Run this in phpMyAdmin or MySQL command line
-- ================================================

CREATE DATABASE IF NOT EXISTS BankingSystem;
USE BankingSystem;

-- ================================================
--  TABLES
-- ================================================

CREATE TABLE IF NOT EXISTS Customers (
    customer_id  INT          AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    phone        VARCHAR(20)  UNIQUE NOT NULL,
    email        VARCHAR(100) UNIQUE,
    city         VARCHAR(50)  NOT NULL,
    created_at   DATETIME     DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Branches (
    branch_id    INT          AUTO_INCREMENT PRIMARY KEY,
    branch_name  VARCHAR(100) NOT NULL,
    location     VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Accounts (
    account_id   INT            AUTO_INCREMENT PRIMARY KEY,
    customer_id  INT            NOT NULL,
    branch_id    INT            NOT NULL,
    account_type VARCHAR(20)    NOT NULL DEFAULT 'SAVINGS',
    balance      DECIMAL(12,2)  DEFAULT 0,
    status       VARCHAR(10)    NOT NULL DEFAULT 'ACTIVE',
    created_at   DATETIME       DEFAULT NOW(),
    CONSTRAINT CHK_AccountType   CHECK (account_type IN ('SAVINGS', 'CURRENT')),
    CONSTRAINT CHK_Balance       CHECK (balance >= 0),
    CONSTRAINT CHK_AccountStatus CHECK (status IN ('ACTIVE', 'FROZEN', 'CLOSED')),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id)   REFERENCES Branches(branch_id)   ON DELETE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS Transactions (
    txn_id       INT            AUTO_INCREMENT PRIMARY KEY,
    sender_acc   INT            NULL,
    receiver_acc INT            NULL,
    amount       DECIMAL(12,2)  NOT NULL,
    txn_type     VARCHAR(20)    NOT NULL,
    txn_date     DATETIME       DEFAULT NOW(),
    CONSTRAINT CHK_Amount           CHECK (amount > 0),
    CONSTRAINT CHK_TxnType          CHECK (txn_type IN ('DEPOSIT', 'WITHDRAW', 'TRANSFER')),
    CONSTRAINT CHK_ValidTransaction  CHECK (sender_acc IS NOT NULL OR receiver_acc IS NOT NULL),
    FOREIGN KEY (sender_acc)   REFERENCES Accounts(account_id) ON DELETE SET NULL,
    FOREIGN KEY (receiver_acc) REFERENCES Accounts(account_id) ON DELETE SET NULL
);

-- ================================================
--  AUDIT LOG TABLE
-- ================================================

CREATE TABLE IF NOT EXISTS AuditLog (
    log_id       INT           AUTO_INCREMENT PRIMARY KEY,
    txn_id       INT           NOT NULL,
    txn_type     VARCHAR(20)   NOT NULL,
    sender_acc   INT           NULL,
    receiver_acc INT           NULL,
    amount       DECIMAL(12,2) NOT NULL,
    logged_at    DATETIME      DEFAULT NOW()
);

-- ================================================
--  INDEXES
-- ================================================

CREATE INDEX IX_Accounts_Customer        ON Accounts(customer_id);
CREATE INDEX IX_Accounts_Branch          ON Accounts(branch_id);
CREATE INDEX IX_Transactions_Sender      ON Transactions(sender_acc);
CREATE INDEX IX_Transactions_Receiver    ON Transactions(receiver_acc);
CREATE INDEX IX_Transactions_Date_Type   ON Transactions(txn_date, txn_type);

-- ================================================
--  VIEWS
-- ================================================

-- Full account detail view (used by accounts list and dashboard)
CREATE VIEW vw_AccountDetail AS
    SELECT
        a.account_id,
        a.account_type,
        a.balance,
        a.status,
        a.created_at,
        c.customer_id,
        c.name    AS customer_name,
        c.phone,
        c.email,
        c.city,
        b.branch_id,
        b.branch_name,
        b.location,
        CASE
            WHEN a.balance < 5000  THEN 'LOW'
            WHEN a.balance < 10000 THEN 'MODERATE'
            ELSE 'GOOD'
        END AS account_status
    FROM Accounts a
    JOIN Customers c ON a.customer_id = c.customer_id
    JOIN Branches  b ON a.branch_id   = b.branch_id;

-- Branch summary view (used by dashboard)
CREATE VIEW vw_BranchSummary AS
    SELECT
        b.branch_id,
        b.branch_name,
        b.location,
        COUNT(a.account_id)       AS total_accounts,
        IFNULL(SUM(a.balance), 0) AS total_balance,
        IFNULL(AVG(a.balance), 0) AS avg_balance
    FROM Branches b
    LEFT JOIN Accounts a ON b.branch_id = a.branch_id
    GROUP BY b.branch_id, b.branch_name, b.location;

-- Transaction history view with customer names resolved
CREATE VIEW vw_TransactionHistory AS
    SELECT
        t.txn_id,
        t.txn_type,
        t.amount,
        t.txn_date,
        t.sender_acc,
        t.receiver_acc,
        sc.name AS sender_name,
        rc.name AS receiver_name
    FROM Transactions t
    LEFT JOIN Accounts  sa ON t.sender_acc   = sa.account_id
    LEFT JOIN Customers sc ON sa.customer_id = sc.customer_id
    LEFT JOIN Accounts  ra ON t.receiver_acc = ra.account_id
    LEFT JOIN Customers rc ON ra.customer_id = rc.customer_id;

-- ================================================
--  TRIGGER  (auto-audit every new transaction)
-- ================================================

DELIMITER $$

CREATE TRIGGER trg_AfterTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (txn_id, txn_type, sender_acc, receiver_acc, amount)
    VALUES (NEW.txn_id, NEW.txn_type, NEW.sender_acc, NEW.receiver_acc, NEW.amount);
END$$

-- ================================================
--  STORED PROCEDURES
-- ================================================

CREATE PROCEDURE TransferMoney(
    IN p_sender   INT,
    IN p_receiver INT,
    IN p_amount   DECIMAL(12,2)
)
BEGIN
    DECLARE sender_balance DECIMAL(12,2);
    DECLARE receiver_exists INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transfer failed due to database error.';
    END;

    IF p_sender = p_receiver THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sender and receiver cannot be the same account.';
    END IF;

    IF p_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transfer amount must be greater than zero.';
    END IF;

    -- Verify receiver account exists and is active
    SELECT COUNT(*) INTO receiver_exists
    FROM Accounts WHERE account_id = p_receiver AND status = 'ACTIVE';

    IF receiver_exists = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Receiver account does not exist or is not active.';
    END IF;

    START TRANSACTION;

    SELECT balance INTO sender_balance
    FROM Accounts
    WHERE account_id = p_sender AND status = 'ACTIVE'
    FOR UPDATE;

    IF sender_balance IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sender account does not exist or is not active.';
    END IF;

    IF sender_balance < p_amount THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance for this transfer.';
    END IF;

    UPDATE Accounts SET balance = balance - p_amount WHERE account_id = p_sender;
    UPDATE Accounts SET balance = balance + p_amount WHERE account_id = p_receiver;

    INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
    VALUES (p_sender, p_receiver, p_amount, 'TRANSFER');

    COMMIT;
END$$

CREATE PROCEDURE DepositWithdraw(
    IN p_acc_id INT,
    IN p_amount DECIMAL(12,2),
    IN p_type   VARCHAR(10)
)
BEGIN
    DECLARE current_balance DECIMAL(12,2);
    DECLARE acc_exists INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaction failed due to database error.';
    END;

    IF p_type NOT IN ('DEPOSIT', 'WITHDRAW') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid type. Use DEPOSIT or WITHDRAW only.';
    END IF;

    IF p_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Amount must be greater than zero.';
    END IF;

    -- Verify account exists and is active
    SELECT COUNT(*) INTO acc_exists
    FROM Accounts WHERE account_id = p_acc_id AND status = 'ACTIVE';

    IF acc_exists = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account does not exist or is not active.';
    END IF;

    START TRANSACTION;

    IF p_type = 'DEPOSIT' THEN
        UPDATE Accounts SET balance = balance + p_amount WHERE account_id = p_acc_id;
        INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
        VALUES (NULL, p_acc_id, p_amount, 'DEPOSIT');
    ELSE
        SELECT balance INTO current_balance
        FROM Accounts WHERE account_id = p_acc_id FOR UPDATE;

        IF current_balance < p_amount THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance for withdrawal.';
        END IF;

        UPDATE Accounts SET balance = balance - p_amount WHERE account_id = p_acc_id;
        INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
        VALUES (p_acc_id, NULL, p_amount, 'WITHDRAW');
    END IF;

    COMMIT;
END$$

DELIMITER ;

-- ================================================
--  SAMPLE DATA
-- ================================================

INSERT INTO Customers (name, phone, email, city) VALUES
('Ali Khan',       '03001234567', 'ali.khan@email.com',       'Lahore'),
('Sara Ahmed',     '03111234567', 'sara.ahmed@email.com',     'Karachi'),
('Usman Tariq',    '03331234567', 'usman.tariq@email.com',    'Islamabad'),
('Ayesha Malik',   '03221234567', 'ayesha.malik@email.com',   'Lahore'),
('Bilal Chaudhry', '03451234567', 'bilal.ch@email.com',       'Karachi');

INSERT INTO Branches (branch_name, location) VALUES
('Main Branch',      'Lahore'),
('City Branch',      'Karachi'),
('Blue Area Branch', 'Islamabad');

INSERT INTO Accounts (customer_id, branch_id, account_type, balance, status) VALUES
(1, 1, 'SAVINGS',  15000, 'ACTIVE'),
(2, 2, 'CURRENT',   9000, 'ACTIVE'),
(3, 3, 'SAVINGS',   4000, 'ACTIVE'),
(4, 1, 'SAVINGS',  20000, 'ACTIVE'),
(5, 2, 'CURRENT',   2500, 'ACTIVE');
