================================================
  BANKING SYSTEM - XAMPP Setup Guide
================================================

STEP 1: DATABASE SETUP
-----------------------
1. Open XAMPP Control Panel
2. Start Apache and MySQL
3. Open browser: http://localhost/phpmyadmin
4. Click "SQL" tab at the top
5. Copy the FULL content of "banking_system.sql"
6. Paste it in phpMyAdmin and click "Go"
7. You will see the BankingSystem database created with sample data

STEP 2: COPY PROJECT FILES
----------------------------
1. Copy the entire "banking_system" folder into:
   C:\xampp\htdocs\banking_system

STEP 3: RUN THE PROJECT
------------------------
1. Make sure XAMPP Apache and MySQL are running
2. Open browser: http://localhost/banking_system
3. The Banking System will open!

================================================
  DEFAULT XAMPP SETTINGS (already configured)
================================================
  Host:     localhost
  Username: root
  Password: (empty)
  Database: BankingSystem

  If your MySQL password is different, edit:
  banking_system/config.php
  Change DB_PASS to your password.

================================================
  FEATURES
================================================
  - Dashboard: Total balance, branch stats,
    recent transactions, low balance alerts
  - Customers: View and add customers
  - Branches:  View and add branches
  - Accounts:  View accounts with status (ACTIVE/FROZEN/CLOSED),
    open new account
  - Transactions: Full history
  - Deposit / Withdraw
  - Transfer Money between accounts

================================================
  SQL FEATURES COVERED
================================================
  Tables:
    - Customers, Branches, Accounts, Transactions
    - AuditLog (auto-populated by trigger)

  Constraints:
    - CHECK constraints on account_type, balance,
      account status, amount, transaction type
    - FOREIGN KEYS on all relationships including
      Transactions.sender_acc and receiver_acc
    - UNIQUE constraints on phone and email

  Stored Procedures:
    - TransferMoney  (with receiver existence check)
    - DepositWithdraw (with account status check)
    - Both use START TRANSACTION / ROLLBACK / COMMIT
    - FOR UPDATE locking prevents race conditions

  Views:
    - vw_AccountDetail      (accounts + customer + branch + status)
    - vw_BranchSummary      (branch totals and averages)
    - vw_TransactionHistory (transactions with customer names)

  Trigger:
    - trg_AfterTransaction: AFTER INSERT on Transactions
      automatically writes every transaction to AuditLog

  Indexes:
    - Accounts(customer_id), Accounts(branch_id)
    - Transactions(sender_acc), Transactions(receiver_acc)
    - Transactions(txn_date, txn_type)  -- composite index

  Other:
    - Aggregate queries: SUM, COUNT, AVG per branch
    - CASE expressions for balance status classification
    - LEFT JOINs for transaction history
================================================
