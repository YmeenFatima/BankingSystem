<?php
require_once '../config.php';

$db       = getDB();
$input    = json_decode(file_get_contents('php://input'), true);
$sender   = intval($input['sender_acc'] ?? 0);
$receiver = intval($input['receiver_acc'] ?? 0);
$amount   = floatval($input['amount'] ?? 0);

if (!$sender || !$receiver || $amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid input. Check account IDs and amount.']);
    exit;
}

if ($sender === $receiver) {
    echo json_encode(['success' => false, 'message' => 'Sender and receiver cannot be the same account.']);
    exit;
}

$stmt = $db->prepare("CALL TransferMoney(?, ?, ?)");
$stmt->bind_param('iid', $sender, $receiver, $amount);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => "Transfer of Rs. " . number_format($amount, 2) . " completed successfully."]);
} else {
    echo json_encode(['success' => false, 'message' => $db->error]);
}

$db->close();
