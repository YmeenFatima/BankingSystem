<?php
require_once '../config.php';

$db = getDB();

$sql = "
    SELECT * FROM vw_TransactionHistory
    ORDER BY txn_date DESC
    LIMIT 100
";

$result = $db->query($sql);
$rows = [];
while ($row = $result->fetch_assoc()) $rows[] = $row;
echo json_encode(['success' => true, 'data' => $rows]);

$db->close();
