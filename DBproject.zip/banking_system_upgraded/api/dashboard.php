<?php
require_once '../config.php';

$db = getDB();

$total_balance = $db->query("SELECT IFNULL(SUM(balance),0) AS total FROM Accounts")->fetch_assoc()['total'];
$total_customers = $db->query("SELECT COUNT(*) AS c FROM Customers")->fetch_assoc()['c'];
$total_accounts  = $db->query("SELECT COUNT(*) AS c FROM Accounts")->fetch_assoc()['c'];
$total_txns      = $db->query("SELECT COUNT(*) AS c FROM Transactions")->fetch_assoc()['c'];

$branch_stats_result = $db->query("SELECT * FROM vw_BranchSummary");
$branch_stats = [];
while ($row = $branch_stats_result->fetch_assoc()) $branch_stats[] = $row;

$low_balance_result = $db->query("
    SELECT account_id, customer_name, balance, account_type, account_status AS status
    FROM vw_AccountDetail
    WHERE balance < 5000
    ORDER BY balance ASC
");
$low_balance = [];
while ($row = $low_balance_result->fetch_assoc()) $low_balance[] = $row;

$recent_txns_result = $db->query("
    SELECT * FROM vw_TransactionHistory
    ORDER BY txn_date DESC LIMIT 5
");
$recent_txns = [];
while ($row = $recent_txns_result->fetch_assoc()) $recent_txns[] = $row;

echo json_encode([
    'success'         => true,
    'total_balance'   => $total_balance,
    'total_customers' => $total_customers,
    'total_accounts'  => $total_accounts,
    'total_txns'      => $total_txns,
    'branch_stats'    => $branch_stats,
    'low_balance'     => $low_balance,
    'recent_txns'     => $recent_txns
]);

$db->close();
